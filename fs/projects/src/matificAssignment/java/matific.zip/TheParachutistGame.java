package matificAssignment.java;

public class TheParachutistGame{
	public static void main(String[] args) {
		GameManager game = new GameManager();
		game.init();
	}
}